mesta = {'praha': None, 'brno': 'jihomoravský', 'ostrava': 'moravskoslezský'}

vstup = input('Zadejte město pro zjištění kraje: ')

try:
    print(f'Kraj města {vstup} je {mesta[vstup]}')
except:
    print(f'Kraj města {vstup} nenalezen')
    

print('\n')

try:
    print(f'Kraj města {vstup} je {mesta[vstup]}')
except IndentationError:
    print(f'Město {vstup} není ve slovníku')
except:
    print('vseobecna chyba')
finally:
    print('Dotazování dokončeno')

    
