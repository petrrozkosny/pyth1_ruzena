def ahoj():
    print("Ahoj")