


def vynasob(a):

    return [i * 4 for i in a]

print()

def pozdrav (*args,**kwargs):
    for k,v in kwargs.items():
        print(v)


pozdrav(text='Ahoj', text2='Ahoj2', text3='Ahoj3')



