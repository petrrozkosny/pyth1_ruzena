import soubour
import funkce_slozka as s


s.super_funkce.soucet(1, 2)


cisla = [1, 2, 3, 4, 5]
vysledek = soubour.vynasob(cisla)