# import pandas as pd



# # cesta_souboru = r'C:\Users\Student\Downloads\2024_03_Seznam-operaci_List-of-Operations_14_20.xlsx'
# # df = pd.read_excel(cesta_souboru,skiprows=3,nrows=100)
# # df = pd.read_csv('https://raw.githubusercontent.com/plotly/datasets/master/2014_us_cities.csv',sep=',')
# # foo = pd.concat([df,df1])
# # print(df.head())
# # exit()

# # rucne vyrobit list 5 nejvetsich mest CR: praha, brno, ostrava, plzen, liberec, nazev listu mesta
# mesta_slovnik ={}
# mesta = ['Praha','Brno','Ostrava','Plzen','Liberec']
# mesta.append('Olomouc')



# for i in mesta:
#     mesta_slovnik[i] = None

# # list klicu
# klice = list(mesta_slovnik.keys())
# print(klice[2])
# mesta_slovnik.pop(klice[2])
# mesta_slovnik.pop(klice[3])

# mesta_slovnik['Praha']=1300000

# hodnoty = list(mesta_slovnik.values())
# pocet_none = hodnoty.count(None)
# set_hodnoty = set(hodnoty)  
# print(set_hodnoty)

# mesta = {'praha':1300000,'praha':400000,'praha':None}

# for k,v in mesta.items():
#     print(v)


udaje = 'varsava, zloty'
udaje = udaje.split(',')
for i in udaje:
    udaj = i.strip()
    print(udaj)
