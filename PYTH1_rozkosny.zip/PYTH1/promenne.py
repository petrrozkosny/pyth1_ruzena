mesto = 'Praha'
kraj = 'B'

def vypis_mesto4():
    print(kraj)
    global mesto
    mesto = 'Brno'
    def vypis():
        # Nastavujeme upravu pro promennou v prilozene oblasti
        
        mesto = 'Ostrava'
        
        def vypis2():
            
            mesto = 'Plzeň'
            print(f'0. {mesto}')
        vypis2()
        print(f'1. {mesto}')

    vypis()
   
    print(f'2. {mesto}')

    
vypis_mesto4()
print(f'3. {mesto}')