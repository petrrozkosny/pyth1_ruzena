
import datetime

zvirata = []
class Zvire():



    def __init__(self,jmeno, datum_narozeni ,barva = None):
        self.jmeno = jmeno
        self.datum_narozeni = datum_narozeni
        self.barva = barva
        self.vek = self.spocti_vek()
        self.obydli = 'obyvak'
        zvirata.append(self)


    def spocti_vek(self):
        dnes = datetime.datetime.now()
        rok = dnes.year
        return rok - self.datum_narozeni


    

morce = Zvire('Rozmarýnka', 2020,'Cerny')
pes = Zvire('Azor', 2015,'Hnedy')
print(pes.obydli)
pes.barva = 'Zeleny'

for zvire in zvirata:
    if zvire.barva == 'Zeleny':
        zvire.obydli = 'zahrada'
print(pes.obydli)
