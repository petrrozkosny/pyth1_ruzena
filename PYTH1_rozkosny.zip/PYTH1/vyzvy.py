import pandas as pd
import plotly.express as px

url = 'https://ms21opendata.mssf.cz/SeznamVyzev_21_27.xml'

# Pandas dataframe
df = pd.read_xml(url)
sloupce = df.columns
dulezite_sloupce = ['ID_PROGRAM','KOD','ALOKACECELKEM','DATUMZPRISTUPNENI']
df = df[dulezite_sloupce]
df = df.dropna()
df['DATUMZPRISTUPNENI'] = df['DATUMZPRISTUPNENI'].apply(lambda x: x[:4]).astype(int)

df = df.groupby('DATUMZPRISTUPNENI')['ALOKACECELKEM'].sum().reset_index()

fig = px.bar(df, x='DATUMZPRISTUPNENI', y='ALOKACECELKEM')
fig.show()


foo = pd.read_csv('https://ms21opendata.mssf.cz/SeznamVyzev_21_27.csv',decimal=',')
