import pandas as pd
import pathlib
import matplotlib.pyplot as plt

cesta_slozky = r'C:\Users\Student\Downloads\data\data\meteo1'
cesta_excel = r'C:\Users\Student\Downloads\data\data\dim_geo.xlsx'
soubory = pathlib.Path(cesta_slozky).glob('*.csv')
df_list = []
for soubor in soubory:
    
    df = pd.read_csv(soubor)
    print(df.shape)
    df_list.append(df)

df_excel = pd.read_excel(cesta_excel)
df_hlavni = pd.concat(df_list)
